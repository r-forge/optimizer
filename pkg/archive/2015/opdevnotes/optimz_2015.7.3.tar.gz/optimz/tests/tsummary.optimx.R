require(optimz)

cat("Show how summary.optimx works\n")

cat("TBA??")
