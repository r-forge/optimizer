require(optimz)

cat("Show how axsearch works\n")

cat("TBA??")
