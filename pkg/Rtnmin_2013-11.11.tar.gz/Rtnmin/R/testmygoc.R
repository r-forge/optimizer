## Run truncated-Newton method to optimize function represented 
## by grosesub.R
require(optimx)
source("grosesub.R")

## Initial guess

n <- 4 # normally 1000
## x <- 5*rnorm(n)
x <- 5*c(pi/(1:n))
print(x)

cat("Constrained example \n")
low <- -.02*rep(1,n) + .005*runif(n,1) ## lower bounds
up  <-  1.90*rep(1,n) + .005*runif(n,1) ## lower bounds

# to check -- run with very wide bounds

low<- -1e100*rep(1,n)
up<- -low

low<- 0:3
up <- 4:7

x<-0.5*(low+up)

print(low)
print(up)

creso <- optimx(x, genrose.f, genrose.g, lower=low, upper=up, method="all")
print(summary(creso, order=value))
