require(optimz)

cat("Show how coef.optimx works\n")

cat("TBA??")
