require(optimz)

cat("Show how bmstep works\n")

cat("TBA??")
