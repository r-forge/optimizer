norm2 <- function (x) {
##---------------------------------------------------------
## compute the 2 norm of vector x
##---------------------------------------------------------
   res<-sqrt(as.numeric(crossprod(x)))
}
