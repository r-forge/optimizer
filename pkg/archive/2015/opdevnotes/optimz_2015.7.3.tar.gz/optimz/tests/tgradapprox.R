require(optimz)

cat("Show how grback, grcentral, grfwd, grnd work\n")

cat("TBA??")
