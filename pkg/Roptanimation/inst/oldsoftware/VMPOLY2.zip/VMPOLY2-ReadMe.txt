Running the VMPOLY2 software.  

J C Nash    2016-12-01

The original VMPOLY2 programs that try to optimize the area of a "small"
polygon (with vertices constrained to be no more than 1 unit distant from
each other) can still be executed. They were written in the Fall of 1985,
more than 31 years ago. I do not have the source file VMPOLY2A.BAS, but
do have its MS-DOS executable file VMPOLY2A.EXE. This will run under Dosbox,
an emulator for MS-DOS that runs under more modern operating systems. I have
only run it under Linux, in particular Linux Mint. See http://www.dosbox.com/.

The source file VMPOLY2Y.BAS did still exist. It can be run under PC-Basic that
runs on any platform that supports Python. Again, I have run this on Linux 
Mint. Downloads are at https://sourceforge.net/projects/pcbasic/, with the
home site at http://robhagemans.github.io/pcbasic/. An alternative is to use
Dosbox and the original GW-BASIC executable, which can still be found on the
Web, e.g., http://www.gw-basic.com/downloads.html.

Needless to say, the tools in the Roptanimation package are more likely to
satisfy.


John Nash