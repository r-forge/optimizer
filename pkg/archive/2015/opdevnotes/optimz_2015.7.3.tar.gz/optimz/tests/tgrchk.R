require(optimz)

cat("Show how grchk works\n")

cat("TBA??")
