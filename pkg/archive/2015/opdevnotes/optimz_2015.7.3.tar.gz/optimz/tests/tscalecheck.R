require(optimz)

cat("Show how scalecheck works\n")

cat("TBA??")
