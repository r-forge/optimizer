require(optimz)

cat("Show how hesschk works\n")

cat("TBA??")
